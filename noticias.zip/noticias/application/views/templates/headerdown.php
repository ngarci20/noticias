<html>

<head>
    <title>Noticialia</title>
    <link rel="stylesheet" href="https://bootswatch.com/4/darkly/bootstrap.min.css">
    <link rel="stylesheet" href="../style.css">
    <style>
        form, input {
            display: inline;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="<?php echo base_url(); ?>"home>Noticialia</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>"home>Inicio <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>economia">Economía</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>deportes">Deportes</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>Api/noticias">API Paginación</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>crud/customers_management">CRUD</a>
      </li>
            <?php $posts = $this->home_model->get_posts();?>
            <?php foreach($posts as $post) : ?>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>Api/noticia/id/<?php echo $post['id_Noticia']?>">ID <?php echo $post['id_Noticia']?></a>
             </li>
            <?php if ($post['id_Noticia'] == 15) : ?>
                <?php break; ?>
            <?php endif; ?>
           
            <?php endforeach; ?>
           
      </ul>
  </div>
</nav>