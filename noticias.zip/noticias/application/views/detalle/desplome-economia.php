<div class="row">
<?php foreach($posts as $post) : ?>
<?php if ($post['slug'] == "desplome-economia") : ?>
<div class="col-sm-12" style="display:inline">
<div style="text-align:center">
<h1 class="col-sm-12" style="text-align:center; margin-bottom:3em"><?php echo $post['Titulo']; ?></h1>
<?php echo $post['Imagen']; ?>
</div>
  <p class="lead" style="text-align:justify; margin-top:3em"><?php echo $post['Contenido']; ?></p>
  <hr class="my-4">
  <p><?php echo $post['Autor']; ?> | <?php echo $post['Fecha']; ?></p>
</div>
<?php endif ?>
<?php endforeach; ?>
</div>
