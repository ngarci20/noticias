<?php
echo '<style>
th, td {
text-align:center; border:solid white 2px;
}
</style>';  
echo '<table>';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>Título</th>';
    echo '<th>Fecha de Publicación</th>';
    echo '</tr>';


foreach ($query->result() as $val):
    echo '<tr>';
    echo '<td>'.$val->id_Noticia.'</td>';
    echo '<td>'.$val->Titulo.'</td>';
    echo '<td>'.$val->Fecha.'</td>';
    echo '</tr>';
endforeach;

echo '</table>';
echo '<br><br> Paginación:';
echo $this->pagination->create_links();


?>