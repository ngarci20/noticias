<?php foreach($posts->result() as $post) : ?>
<div class="row">
<div class="col-sm-12">
<div style="text-align:center">
<h1 class="col-sm-12" style="text-align:center"><?php echo $post->Titulo; ?></h1>
<p class="lead" style="text-align:justify; margin-top:3em"><?php echo $post->Cabecera; ?></p>
<?php echo $post->Imagen; ?>
</div>
  <p class="lead" style="text-align:justify; margin-top:3em"><?php echo $post->Contenido; ?></p>
  <hr class="my-4">
  <p><?php echo $post->Autor; ?> | <?php echo $post->Fecha; ?></p>
</div>
<?php endforeach; ?>
</div>
