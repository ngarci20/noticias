<div class="row">
<?php foreach($posts as $post) : ?>
<?php if ($post['id_Noticia'] <= 12) : ?>
<div class="col-sm-1"></div>
<div class="col-sm-4" style="display:inline">
<div style="text-align:center">
<?php echo $post['Imagen']; ?>
<h2><?php echo $post['Titulo']; ?></h2>
</div>
  <p class="lead" style="text-align:justify"><?php echo $post['Cabecera']; ?></p>
  <p><?php echo $post['Autor']; ?> | <?php echo $post['Fecha']; ?></p>
  <p class="lead" style="text-align:center">
    <a class="btn btn-primary btn-lg" href="<?php echo base_url('/detalle/'.$post['slug']); ?>" role="button">Leer Más</a>
</p>

    
 <hr class="my-4">
</div>
<div class="col-sm-1"></div>
<?php endif ?>
<?php endforeach; ?>
    </div>