<div class="row">
<h1 class="col-sm-12" style="text-align:center; margin-bottom:3em">Deportes</h1>
<?php foreach($posts as $post) : ?>
<?php if ($post['id_Noticia'] <= 12 && $post['id_Cat'] == 1) : ?>
<div class="col-sm-1"></div>
<div class="col-sm-4" style="display:inline">
<div style="text-align:center">
<?php echo $post['Imagen']; ?>
<h3><?php echo $post['Titulo']; ?></h3>
</div>
  <p class="lead" style="text-align:justify"><?php echo $post['Cabecera']; ?></p>
  
  <p><?php echo $post['Autor']; ?> | <?php echo $post['Fecha']; ?></p>
  <div class="lead" style="text-align:center; margin-bottom:4em">
    <a class="btn btn-primary btn-lg" href="<?php echo base_url('/detalle/'.$post['slug']); ?>" role="button">Leer Más</a>
</div>
    <hr class="my-4">
</div>
<div class="col-sm-1"></div>
<?php endif ?>
<?php endforeach; ?>
</div>
