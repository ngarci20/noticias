<?php
	class home_model extends CI_Model {
        public function __construct(){
			$this->load->database();
		}
        
        public function get_posts(){
                //$this->db->order_by('Fecha', 'DESC');
				$query = $this->db->get('noticia');
				return $query->result_array();
			   
        }
        
        
    }
