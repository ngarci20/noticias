<?php

class Api extends CI_Controller {
    public function noticias() {
        $this->load->library('pagination');
        $config['base_url'] = 'http://localhost/noticias/Api/noticias/page/';
        $config['per_page'] = 10;
        $config['num_links'] = 2;
        $config['total_rows'] = $this->db->get('noticia')->num_rows();
        $this->pagination->initialize($config);
        $data['query'] = $this->db->get('noticia', $config['per_page'], $this->uri->segment(4));
        $this->load->view('templates/header');
        $this->load->view('api/noticias', $data);
    }
    
    public function noticia() {
        
        $this->load->library('pagination');
        $config['base_url'] = 'http://localhost/noticias/Api/noticia/id/';
        $config['per_page'] = 1;
        $this->pagination->initialize($config);
                        
        $postData = 1;
        $data['response'] = $postData;  
        $data['posts'] = $this->db->get('noticia', $config['per_page'], $this->uri->segment(4));
        $this->load->view('templates/header');
        $this->load->view('api/noticia', $data);
        

    }
    

}