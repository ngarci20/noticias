<?php
	class Detalle extends CI_Controller{
        
            public function crisis($page = 'crisis-economica'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/crisis-economica', $data);
			$this->load->view('templates/footer');
		}
        
            public function domingos($page = 'abrir-domingos'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/abrir-domingos', $data);
			$this->load->view('templates/footer');
		}
        
            public function bolsa($page = 'bolsa-usa'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/bolsa-usa', $data);
			$this->load->view('templates/footer');
		}
        
            public function messi($page = 'messi-copa'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/messi-copa', $data);
			$this->load->view('templates/footer');
		}
        
            public function plazas($page = 'plazas-liga'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/plazas-liga', $data);
			$this->load->view('templates/footer');
		}
        
        public function desplome($page = 'desplome-economia'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/desplome-economia', $data);
			$this->load->view('templates/footer');
		}
            public function iniesta($page = 'version-iniesta'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/version-iniesta', $data);
			$this->load->view('templates/footer');
		}
            public function infarto($page = 'partido-infarto'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/partido-infarto', $data);
			$this->load->view('templates/footer');
		}
            public function contador($page = 'alberto-contador'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/alberto-contador', $data);
			$this->load->view('templates/footer');
		}
            public function agencia($page = 'agencia-tributaria'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/agencia-tributaria', $data);
			$this->load->view('templates/footer');
		}
            public function naturgy($page = 'naturgy-compra'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/naturgy-compra', $data);
			$this->load->view('templates/footer');
		}
            public function deportistas($page = 'deportistas-salen'){
			if(!file_exists(APPPATH.'views/detalle/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('detalle/deportistas-salen', $data);
			$this->load->view('templates/footer');
		}
}
