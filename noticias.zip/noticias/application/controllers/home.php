<?php
	class Home extends CI_Controller{
		public function index($page = 'index'){
			if(!file_exists(APPPATH.'views/home/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('home/index', $data);
			$this->load->view('templates/footer');
		}
	}
