<?php
	class Cats extends CI_Controller{
        
     public function economia($page = 'economia'){
			if(!file_exists(APPPATH.'views/cats/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('cats/economia', $data);
			$this->load->view('templates/footer');
		}
        
        public function deportes($page = 'deportes'){
			if(!file_exists(APPPATH.'views/cats/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);
            
            $data['posts'] = $this->home_model->get_posts();

			if(empty($data['posts'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('cats/deportes', $data);
			$this->load->view('templates/footer');
		}
}