<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'home/index';
$route['(:any)'] = 'home/index/$1';
$route['(:any)'] = 'cats/$1';
$route[('detalle/crisis-economica')] = 'detalle/crisis';
$route[('detalle/abrir-domingos')] = 'detalle/domingos';
$route[('detalle/bolsa-usa')] = 'detalle/bolsa';
$route[('detalle/messi-copa')] = 'detalle/messi';
$route[('detalle/plazas-liga')] = 'detalle/plazas';
$route[('detalle/desplome-economia')] = 'detalle/desplome';
$route[('detalle/version-iniesta')] = 'detalle/iniesta';
$route[('detalle/partido-infarto')] = 'detalle/infarto';
$route[('detalle/alberto-contador')] = 'detalle/contador';
$route[('detalle/agencia-tributaria')] = 'detalle/agencia';
$route[('detalle/naturgy-compra')] = 'detalle/naturgy';
$route[('detalle/deportistas-salen')] = 'detalle/deportistas';
$route[('crud/crudview')] = 'crud/crudview';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
